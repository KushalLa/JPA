package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class EmployeeTest {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU"); //object of EMF
		EntityManager entityManager=  entityManagerFactory.createEntityManager(); 	// object of EM
		entityManager.getTransaction().begin();	//transaction boundary starts

		/*Employee employee=new Employee(1002,"John",6520);   //object in transient state
				Employee employee=new Employee();	//id will come from sequence
				employee.setEmployeeName("hhh");
				employee.setEmployeeSalary(15000);
		
		
		entityManager.persist(employee);
		*/
		
		/*Employee employee= entityManager.find(Employee.class, 2); 	//4 is a primary key nd we want data of vol where id = 4
		
		if(employee==null)
		{
			System.out.println("Employee not found");
		}
		else
		{
			//entityManager.detach(employee);	// detach employee object
			//employee.setEmployeeSalary(15000); // after detach it will not work
			//entityManager.clear();	// clear all objects
			//System.out.println(employee.getEmployeeName()+" "+employee.getEmployeeSalary());
			entityManager.remove(employee);  // to delete row with id=?
			System.out.println("Employee removed successfully!!!");
			employee.setEmployeeName("Johny");	//update name
			entityManager.merge(employee);
			System.out.println("Employee updated successfully!!!");

		}
		*/
		
		
		//Query: 
		/*Query query = entityManager.createQuery("from Employee"); //or "select e from Employee e" & never use table name in JPQL, use class name 
		List list=query.getResultList(); 	//gives list of objects
		
		for(Object object : list)
		{
			Employee employee = (Employee) object;
			System.out.println(employee.getEmployeeId()+" "+employee.getEmployeeName()+" "+employee.getEmployeeSalary());
		}*/
		
		/*//TypedQuery:
		TypedQuery<Employee> query=entityManager.createQuery("from Employee where employeeId=4", Employee.class);
		List<Employee> list = query.getResultList();
		
		for(Employee employee : list)
		{
			System.out.println(employee.getEmployeeId()+" "+employee.getEmployeeName()+" "+employee.getEmployeeSalary());
		}*/
		
		
		//for 1 row only:
		//positional parameter
		/*TypedQuery<Employee> query=entityManager.createQuery("from Employee where employeeId=?", Employee.class);
		
		query.setParameter(1,4); // change value of ? in query, first value is one question mark    
*/		
		//Named Parameter
		/*TypedQuery<Employee> query=entityManager.createQuery("from Employee where employeeId=:id", Employee.class);
		query.setParameter("id",4); // change value of named param in query, first value is param    
		Employee employee=query.getSingleResult();
		System.out.println(employee.getEmployeeId()+" "+employee.getEmployeeName()+" "+employee.getEmployeeSalary());
*/
		//Named Query
		TypedQuery<Employee> query= entityManager.createNamedQuery("viewAllEmployee",Employee.class);
		
		List <Employee> list = query.getResultList();
		for(Employee employee : list)
		{
			System.out.println(employee.getEmployeeId()+" "+employee.getEmployeeName()+" "+employee.getEmployeeSalary());

		}
		
		entityManager.getTransaction().commit();   //transaction boundary commits
		//System.out.println("Employee added to Database");
		
		entityManager.close();
		entityManagerFactory.close();
	}

}
