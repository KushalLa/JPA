import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		
		Author author = new Author();
		author.setAuthorName("Chetan B.");
		
		Book book = new Book();
		book.setBookName("2 States");
		book.setPrice(265);
		
		Book book2 = new Book();
		book2.setBookName("Revolution 2020");
		book2.setPrice(285);
		
		author.addBook(book);
		author.addBook(book2);
		
		em.persist(author);
		
		em.getTransaction().commit();
		System.out.println("Added department along with two employees to database.");

		
		em.close();
		factory.close();
		}
}

