package com.test;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class TestMapping {

	public static void main(String[] args) {
		
		EntityManagerFactory entityManagerFactory=Persistence.createEntityManagerFactory("JPA-PU"); //object of EMF
		EntityManager entityManager=  entityManagerFactory.createEntityManager(); 	// object of EM
		entityManager.getTransaction().begin();
		
		String qrystr = "from Employee where department.departmentId>24";
		
		TypedQuery<Employee> query=entityManager.createQuery(qrystr, Employee.class);
		List<Employee> list = query.getResultList();
		
		for(Employee employee : list)
		{
			System.out.println(employee.getEmployeeId()+" "+employee.getEmployeeName()+" "+employee.getDepartment().getDepartmentName());
		}
		
		entityManager.getTransaction().commit();   
		//System.out.println(" Employee Added");
		entityManager.close();
		entityManagerFactory.close();
	}

}
