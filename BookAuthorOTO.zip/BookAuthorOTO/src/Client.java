import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;


public class Client {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		Scanner sc= new Scanner(System.in);
		
		
		Book b1 = new Book();
		Author a1 = new Author();
		
		
		System.out.println("Enter Book Details");
	
		
		System.out.println("Enter Book Name");
		String name = sc.next();
		b1.setBookName(name);
		
		System.out.println("Enter Book Price");
		int price = sc.nextInt();
					sc.nextLine();
		b1.setPrice(price);
		
		System.out.println("Enter Author Name");
		String authName = sc.nextLine();
		a1.setAuthorName(authName);
	
		TypedQuery<Book> query = em.createNamedQuery("viewAllBooks", Book.class);
		List<Book> list = query.getResultList();
		
		for(Book b2 : list)
		{
			System.out.println(b2.getBookId()+" "+b2.getBookName()+" "+b2.getPrice()+" "+b2.getAuthor().getAuthorId()+" "+b2.getAuthor().getAuthorName());
		}
		
		String qrystr1 = "from Book where author.authorName='Khalid'";
		
		TypedQuery<Book> query1=em.createQuery(qrystr1, Book.class);
		List<Book> list1 = query1.getResultList();
		
		for(Book book1 : list)
		{
			System.out.println(book1.getBookId()+" "+book1.getBookName()+" "+book1.getPrice()+" "+book1.getAuthor().getAuthorId()+" "+book1.getAuthor().getAuthorName());
		}
		
		String qrystr2 = "from Book where price between 500 and 1000";
			
		TypedQuery<Book> query2=em.createQuery(qrystr2, Book.class);
		List<Book> list2 = query2.getResultList();
		
		for(Book book2 : list)
		{
			System.out.println(book2.getBookId()+" "+book2.getBookName()+" "+book2.getPrice()+" "+book2.getAuthor().getAuthorId()+" "+book2.getAuthor().getAuthorName());
		}
		
		String qrystr3 = "from Book where bookId=7";
		
		TypedQuery<Book> query3=em.createQuery(qrystr3, Book.class);
		List<Book> list3 = query3.getResultList();
		
		for(Book book : list)
		{
			System.out.println(book.getAuthor().getAuthorName());
		}
		
		em.getTransaction().commit();
		em.close();
		factory.close();
		}
}

